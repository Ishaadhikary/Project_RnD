function Gold()
{
    var message= document.getElementById("describe");
    window.alert("We Serve you with HBD Ballons, Candles and the theme according to you!");
}

function Platinum()
{
    var message= document.getElementById("describe1");
    window.alert("We Serve you with HBD Ballons, Scented Candles and design the environment according to you!");
}

function Silver()
{
    var message= document.getElementById("describe2");
    window.alert("We Serve you with HBD Ballons,Romantic Candles and design the environment according to you!");
}
