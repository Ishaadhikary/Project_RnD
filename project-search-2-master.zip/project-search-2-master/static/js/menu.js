function call1(){
 var elem = document.getElementById("ordernow1");
 if(elem.value == "Add to Cart") elem.value = "Added to Cart";
 else elem.value ="Add to Cart";
}
function call2(){
    var elem = document.getElementById("ordernow2");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }

   function call3(){
    var elem = document.getElementById("ordernow3");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   
   function call4(){
    var elem = document.getElementById("ordernow4");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   
   function call5(){
    var elem = document.getElementById("ordernow5");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   
   function call6(){
    var elem = document.getElementById("ordernow6");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   
   function call7(){
    var elem = document.getElementById("ordernow7");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }

   function call8(){
    var elem = document.getElementById("ordernow8");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   function call9(){
    var elem = document.getElementById("ordernow9");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   function call10(){
    var elem = document.getElementById("ordernow10");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   function call11(){
    var elem = document.getElementById("ordernow11");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }
   function call12(){
    var elem = document.getElementById("ordernow12");
    if(elem.value == "Add to Cart") elem.value = "Added to Cart";
    else elem.value ="Add to Cart";
   }