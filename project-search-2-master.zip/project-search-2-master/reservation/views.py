from django.shortcuts import render, HttpResponse
from django.views.generic import ListView, FormView, View
from .models import Table, Reservation
from .form import AvailabilityForm
from .reservation_function.availability import check_avaiability

# Create your views here.
class ReservationList(ListView):
    model=Reservation

class TableList(ListView):
    model=Table   

    

class ReservationView(FormView):
    form_class=AvailabilityForm
    template_name='availability_form.html'

def form_valid(self, form):
    data=form.cleaned_data
    table_list=Table.objects.filter(capacity=data['total_capacity'])
    avaliable_table=[]
    for table in table_list:
        if check_avaiability(table,data['check_in'],data['check_out']):
            avaliable_table.append(table)
    
    if len(avaliable_table>0):
        table=avaliable_table[0]
        reserved=Reservation.object.create(
            user=self.request.user,
            table=table,
            check_in=data['check_in'],
            check_out=data['check_out']
        )        
        reserved.save()
        return HttpResponse(reserved)
    else:
        return HttpResponse('The capacity of table is already booked!Try aonther one')


#########
