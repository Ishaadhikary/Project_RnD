import datetime
from reservation.models import Reservation, Table
#from django.db.models import Q


def check_avaiability(table_number, check_in, check_out):
    table_avib_list=list()
    same_table_list=Table.objects.filter(table_number=table_number)
    for table in same_table_list:
        if table.check_in>check_out or table.check_out<check_in:
            table_avib_list.append(True)
        else:
            table_avib_list.append(False)
    return all(table_avaib_list)   


           