from django.urls import path
from .views import ReservationList, TableList,ReservationView
app_name = 'reservation'
#app_name='items'


urlpatterns = [
    #path('menu/', views.index, name='menu'),
    path('reservation/', ReservationList.as_view()),
    path('tablelist/', TableList.as_view()),
    path('reservation1/', ReservationView.as_view())
    
    ]